import React, { useState } from 'react'
import {
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CForm,
  CFormCheck,
  CFormFeedback,
  CFormInput,
  CFormLabel,
  CInputGroup,
  CInputGroupText,
  CRow,
  CButton,
  CFormSelect,
} from '@coreui/react'
import { DocsLink } from 'src/components'

const Appoinment = () => {
  const [validated, setValidated] = useState(false)

  const handleSubmit = (event) => {
    const form = event.currentTarget
    if (form.checkValidity() === false) {
      event.preventDefault()
      event.stopPropagation()
    }
    setValidated(true)
  }

  return (
    <>
      <CCard className="mb-5">
        <CCardHeader>
          Appoinment Details
          <DocsLink href="https://coreui.io/docs/utilities/colors/" />
        </CCardHeader>
        <CCardBody>
          <CForm
            className="row g-3 ml needs-validation"
            noValidate
            validated={validated}
            onSubmit={handleSubmit}
          >
            <CCol md={4}>
              <CFormInput
                type="text"
                defaultValue=""
                feedbackValid="Looks good!"
                id="validationCustom01"
                label="First name"
                required
              />
            </CCol>
            <CCol md={4}>
              <CFormInput
                type="text"
                defaultValue=""
                feedbackValid="Looks good!"
                id="validationCustom02"
                label="Last name"
                required
              />
            </CCol>
            <CCol md={4}>
              <CFormInput
                type="date"
                defaultValue=""
                feedbackValid="Looks good!"
                id="validationCustom03"
                label="Date of Birth"
                required
              />
            </CCol>
            <CCol md={4}>
              <CFormSelect
                aria-describedby="validationCustom04Feedback"
                feedbackInvalid="Please select a valid sex."
                id="validationCustom04"
                label="Sex"
                required
              >
                <option disabled>Choose...</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </CFormSelect>
            </CCol>
            <CCol>
              <CFormInput
                type="number"
                defaultValue=""
                feedbackValid="Looks good!"
                id="validationCustom05"
                label="Height (inches)"
                required
              />
            </CCol>
            <CCol md={4}>
              <CFormInput
                type="number"
                defaultValue=""
                feedbackValid="Looks good!"
                id="validationCustom06"
                label="Weight (pounds)"
                required
              />
            </CCol>

            <CCol md={4}>
              <CFormInput
                type="text"
                aria-describedby="validationCustom03Feedback"
                feedbackInvalid="Please provide a valid city."
                id="validationCustom03"
                label="City"
                required
              />
            </CCol>
            <CCol md={4}>
              <CFormSelect
                aria-describedby="validationCustom04Feedback"
                feedbackInvalid="Please select a valid state."
                id="validationCustom04"
                label="State"
                required
              >
                <option disabled>Choose...</option>
                <option>...</option>
              </CFormSelect>
            </CCol>
            <CCol md={4}>
              <CFormInput
                type="text"
                aria-describedby="validationCustom05Feedback"
                feedbackInvalid="Please provide a valid Pincode."
                id="validationCustom05"
                label="Pincode"
                required
              />
            </CCol>
            <CCol md={4}>
              <CFormSelect
                aria-describedby="validationCustom07Feedback"
                feedbackInvalid="Please select a valid marital status."
                id="validationCustom07"
                label="Marital Status"
                required
              >
                <option disabled>Choose...</option>
                <option value="single">Single</option>
                <option value="married">Married</option>
                <option value="divorced">Divorced</option>
                <option value="widowed">Widowed</option>
              </CFormSelect>
            </CCol>
            <CCol md={4}>
              <CFormInput
                type="tel"
                defaultValue=""
                feedbackValid="Looks good!"
                id="validationCustom08"
                label="Contact Number"
                required
              />
            </CCol>
            <CCol md={4}>
              <CFormInput
                type="email"
                defaultValue=""
                feedbackValid="Looks good!"
                id="validationCustom09"
                label="E-mail"
                required
              />
            </CCol>
            <CCol md={4}>
              <CFormInput
                type="text"
                defaultValue=""
                feedbackValid="Looks good!"
                id="validationCustom10"
                label="Address"
                required
              />
            </CCol>
            <CCol md={4}>
              <CFormSelect
                aria-describedby="validationCustom11Feedback"
                feedbackInvalid="Please select an option."
                id="validationCustom11"
                label="Taking any medications, currently?"
                required
              >
                <option disabled>Choose...</option>
                <option value="yes">Yes</option>
                <option value="no">No</option>
              </CFormSelect>
            </CCol>
            <CCol md={4}></CCol>
            <CCol xs={4}>
              <CFormCheck
                type="checkbox"
                id="invalidCheck"
                label="Agree to terms and conditions"
                required
              />
              <CFormFeedback invalid>You must agree before submitting.</CFormFeedback>
            </CCol>
            <CCol md={4}></CCol>
            <CCol md={4}></CCol>

            <CCol xs={4}>
              <CButton color="primary" type="submit">
                Submit form
              </CButton>
            </CCol>
          </CForm>
        </CCardBody>
      </CCard>
    </>
  )
}

export default Appoinment
