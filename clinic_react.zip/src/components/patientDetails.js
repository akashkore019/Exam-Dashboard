import React, { useState, useEffect } from 'react'
import axios from 'axios'
import {
  CCard,
  CCardBody,
  CTable,
  CTableHead,
  CTableHeaderCell,
  CTableDataCell,
} from '@coreui/react'

const Patient = () => {
  const [patients, setPatients] = useState([])

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://192.168.0.21:8080/api/v1/patients')
        setPatients(response.data)
      } catch (error) {
        console.error('Error fetching data:', error)
      }
    }

    fetchData()
  }, [])

  const columns = [
    { key: 'id', label: 'Id', _props: { scope: 'col' } },
    { key: 'fullName', label: 'Full Name', _props: { scope: 'col' } },
    { key: 'mobile', label: 'Mobile', _props: { scope: 'col' } },
    { key: 'email', label: 'Email', _props: { scope: 'col' } },
    { key: 'address', label: 'Address', _props: { scope: 'col' } },
    { key: 'gender', label: 'Gender', _props: { scope: 'col' } },
    { key: 'dob', label: 'Date of Birth', _props: { scope: 'col' } },
    { key: 'age', label: 'Age', _props: { scope: 'col' } },
    { key: 'weight', label: 'Weight', _props: { scope: 'col' } },
    { key: 'bloodGroup', label: 'Blood Group', _props: { scope: 'col' } },
  ]

  return (
    <CCard className="mb-5">
      <CCardBody>
        <CTable>
          <CTableHead>
            <tr>
              {columns.map((column) => (
                <CTableHeaderCell {...column._props} key={column.key}>
                  {column.label}
                </CTableHeaderCell>
              ))}
            </tr>
          </CTableHead>
          <tbody>
            {patients.map((patient) => (
              <tr key={patient.id}>
                {columns.map((column) => (
                  <CTableDataCell key={column.key}>{patient[column.key]}</CTableDataCell>
                ))}
              </tr>
            ))}
          </tbody>
        </CTable>
      </CCardBody>
    </CCard>
  )
}

export default Patient
